package de.codecrafters.tableviewexample.data;


/**
 * An interface for chagrable items.
 *
 * @author ISchwarz
 */
public interface Chargable {

    double getPrice();

}
